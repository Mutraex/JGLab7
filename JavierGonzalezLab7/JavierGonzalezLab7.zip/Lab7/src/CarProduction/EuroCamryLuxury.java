package CarProduction;

public class EuroCamryLuxury implements ToyotaCar {

	public EuroCamryLuxury(){
		
	}
	public void features() {
		System.out.println("European Toyota Camry Luxury Package features include: Standard European Engine, AM/FM Radio, XM Radio,"
				+ " Bluetooth Connectivity, Right Sided Steering Wheel");
	}

}

package CarProduction;

public class AsiaCorollaLuxury implements ToyotaCar {

	public AsiaCorollaLuxury(){
		
	}
	public void features() {
		System.out.println("Asian Toyota Corolla Luxury Package features include: Standard Asian Engine, AM/FM Radio, XM Radio,"
				+ " Bluetooth Connectivity, Right Sided Steering Wheel");
	}

}

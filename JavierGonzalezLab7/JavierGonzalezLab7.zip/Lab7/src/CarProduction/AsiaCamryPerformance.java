package CarProduction;

public class AsiaCamryPerformance implements ToyotaCar {

	public AsiaCamryPerformance(){
		
	}
	public void features() {
		System.out.println("Asian Toyota Camry Performance Package features include: Advanced Asian Engine, AM/FM Radio,"
				+ " Bluetooth Connectivity, Right Sided Steering Wheel, 4 Spare Tires");
	}

}

package CarProduction;

public class EuroCorollaPerformance implements ToyotaCar {

	public EuroCorollaPerformance(){
		
	}
	public void features() {
		System.out.println("European Toyota Corolla Performance Package features include: Advanced European Engine, AM/FM Radio,"
				+ " Bluetooth Connectivity, Right Sided Steering Wheel, 4 Spare Tires");
	}

}

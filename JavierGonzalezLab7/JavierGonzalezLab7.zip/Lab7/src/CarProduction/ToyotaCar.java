package CarProduction;

public interface ToyotaCar {

	public void features();
	
}

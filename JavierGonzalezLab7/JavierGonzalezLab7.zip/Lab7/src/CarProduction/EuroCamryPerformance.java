package CarProduction;

public class EuroCamryPerformance implements ToyotaCar {

	public EuroCamryPerformance(){
		
	}
	public void features() {
		System.out.println("European Toyota Camry Performance Package features include: Advanced European Engine, AM/FM Radio,"
				+ " Bluetooth Connectivity, Right Sided Steering Wheel, 4 Spare Tires");
	}

}

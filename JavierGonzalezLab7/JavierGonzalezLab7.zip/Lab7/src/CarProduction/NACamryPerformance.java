package CarProduction;

public class NACamryPerformance implements ToyotaCar {

	public NACamryPerformance(){
		
	}
	public void features() {
		System.out.println("North American Toyota Camry Performance Package features include: Advanced North American Engine, AM/FM Radio," 
				+ " Left Sided Steering Wheel, 4 Spare Tires");
	}

}

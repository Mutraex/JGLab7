package CarProduction;

public class NACorollaLuxury implements ToyotaCar {

	public NACorollaLuxury(){
		
	}
	public void features() {
		System.out.println("North American Toyota Corolla Luxury Package features include: Standard North American Engine, AM/FM Radio, XM Radio," + 
				" Bluetooth Connectivity, Left Sided Steering Wheel");
	}

}

package CarProduction;

public interface CarFactory {

	public ToyotaCar createCar(String model, String pack);
}

package CarProduction;

public class AsiaCorollaPerformance implements ToyotaCar {

	public AsiaCorollaPerformance(){
		
	}
	public void features() {
		System.out.println("Asian Toyota Corolla Performance Package features include: Advanced Asian Engine, AM/FM Radio,"
				+ " Bluetooth Connectivity, Right Sided Steering Wheel, 4 Spare Tires");
	}

}

package CarProduction;

public class NACamryLuxury implements ToyotaCar {

	public NACamryLuxury(){
		
	}
	public void features() {
		System.out.println("North American Toyota Camry Luxury Package features include: Standard North American Engine, AM/FM Radio, XM Radio,"
				+ ", Bluetooth Connectivity, Left Sided Steering Wheel");
	}

}

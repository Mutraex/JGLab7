package CarProduction;

public class AsiaCamryLuxury implements ToyotaCar {

	public AsiaCamryLuxury(){
		
	}
	public void features() {
		System.out.println("Asian Toyota Camry Luxury Package features include: Standard Asian Engine, AM/FM Radio, XM Radio,"
				+ " Bluetooth Connectivity, Right Sided Steering Wheel");
	}

}

package CarProduction;

public class NACorollaPerformance implements ToyotaCar {

	public NACorollaPerformance(){
		
	}
	public void features() {
		System.out.println("North American Toyota Corolla Performance Package features include: Advanced North American Engine, AM/FM Radio,"
				+ " Bluetooth Connectivity, Left Sided Steering Wheel, 4 Spare Tires");
	}

}

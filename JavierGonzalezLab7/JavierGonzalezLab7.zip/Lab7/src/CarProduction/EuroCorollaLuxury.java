package CarProduction;

public class EuroCorollaLuxury implements ToyotaCar {

	public EuroCorollaLuxury(){
		
	}
	public void features() {
		System.out.println("European Toyota Corolla Luxury Package features include: Standard European Engine, AM/FM Radio, XM Radio,"
				+ " Bluetooth Connectivity, Right Sided Steering Wheel");
	}

}
